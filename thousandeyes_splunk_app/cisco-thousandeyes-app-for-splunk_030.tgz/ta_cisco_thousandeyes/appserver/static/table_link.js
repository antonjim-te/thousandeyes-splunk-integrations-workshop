require([
  "splunkjs/mvc",
  "splunkjs/mvc/tableview",
  "splunkjs/mvc/searchmanager",
  "splunkjs/mvc/simplexml/ready!",
], function (mvc, TableView, SearchManager) {
  var app_dd_1 = mvc.Components.get("app_dd_1");
  var app_dd_2 = mvc.Components.get("app_dd_2");
  var app_dd_3 = mvc.Components.get("app_dd_3");
  var app_dd_4 = mvc.Components.get("app_dd_4");
  var app_dd_5 = mvc.Components.get("app_dd_5");
  var app_dd_6 = mvc.Components.get("app_dd_6");
  var app_dd_7 = mvc.Components.get("app_dd_7");
  var app_dd_8 = mvc.Components.get("app_dd_8");
  var event_table = mvc.Components.get("event_table");

  customRenderer = TableView.BaseCellRenderer.extend({
    canRender: function (cell) {
      return "links" === cell.field || "Title" === cell.field;
    },
    render: function ($td, cell) {
      if (cell.field == "links") {
        var all_value = cell.value;
        var values = all_value.split("~");
        if (values.length >= 4) {
          var test_id = values[0];
          var test_name = values[1];
          var agent = values[2];
          var link = values[3];
          $td.html(
            "<div ><a href='" +
              link +
              "'>Link to ThousandEyes Test " +
              test_name +
              " (" +
              test_id +
              "), Agent " +
              agent +
              "</a></div>"
          );
          $td.on("click", function (event) {
            window.open(link);
          });
        } else {
          var test_id = values[0];
          var test_name = values[1];
          var link = values[2];
          $td.html(
            "<div ><a href='" +
              link +
              "'>Link to ThousandEyes Test " +
              test_name +
              " (" +
              test_id +
              ")</a></div>"
          );
          $td.on("click", function (event) {
            window.open(link);
          });
        }
      }
      if (cell.field === "Title") {
        var values = cell.value.split("~");
        var title = values[0];
        var link = values[1];
        $td.html("<div ><a href='" + link + "'>" + title + "</a></div>");
        $td.on("click", function (event) {
          window.open(link);
        });
      }
    },
  });

  if (event_table !== undefined) {
    event_table.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_1 !== undefined) {
    app_dd_1.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_2 !== undefined) {
    app_dd_2.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_3 !== undefined) {
    app_dd_3.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_4 !== undefined) {
    app_dd_4.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }
  if (app_dd_5 !== undefined) {
    app_dd_5.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_6 !== undefined) {
    app_dd_6.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_7 !== undefined) {
    app_dd_7.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }

  if (app_dd_8 !== undefined) {
    app_dd_8.getVisualization(function (tableView) {
      // Add custom cell renderer and force re-render.
      tableView.table.addCellRenderer(new customRenderer());
      tableView.table.render();
    });
  }
});
