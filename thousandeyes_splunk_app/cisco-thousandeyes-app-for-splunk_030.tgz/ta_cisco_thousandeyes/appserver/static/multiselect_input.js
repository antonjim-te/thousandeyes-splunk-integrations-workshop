require(["splunkjs/mvc", "splunkjs/mvc/simplexml/ready!"], function (mvc) {
  // Multiselect will remove "All" if specific value is selected and vise-versa

  function setupMultiInput(instance_id) {
    var multiselect = mvc.Components.get(instance_id);

    if (multiselect) {
      multiselect.on("change", function () {
        let current_val = multiselect.val();
        let first_choice_value = multiselect.options.choices[0].value;
        if (
          current_val.length > 1 &&
          current_val.indexOf(first_choice_value) == 0
        ) {
          multiselect.val(
            current_val.filter((item) => item !== first_choice_value)
          );
        }
        if (
          current_val.length > 1 &&
          current_val.includes(first_choice_value) &&
          current_val.indexOf(first_choice_value) != 0
        ) {
          multiselect.val([first_choice_value]);
        }
      });
    }
  }
  // ids of multiselects to apply special filter options
  var all_multi_selects = document.getElementsByClassName("input-multiselect");
  for (let j = 0; j < all_multi_selects.length; j++) {
    setupMultiInput(all_multi_selects[j].id);
  }
});
